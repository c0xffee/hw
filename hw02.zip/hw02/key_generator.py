import random

a = [chr(i+65) for i in range(26)]
b = [chr(i+65) for i in range(26)]

random.shuffle(b)
#fname = input("key_file_name: ")

with open('key.txt', 'w') as f:
  for i in range(26):
    pat = "%s : %s\n" %(a[i], b[i])
    print(pat, end='')
    f.write(pat)
    
print("key was saved in key.txt")