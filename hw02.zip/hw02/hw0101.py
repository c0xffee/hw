import sys

inpfile = input("Please enter the input file: ")
outfile = input("Please enter the output file: ")
keyfile = input("Please enter the key file: ")
EorD = input("Encryption (1) or Decryption (2): ")


with open(inpfile, 'r') as f:
  inp = f.read()

with open(keyfile, 'r') as f:
  key = f.read()


ori = []
aft = []
for k in [i for i in key.split('\n') if i != '']:
  tmp = k.split(':')
  a = tmp[0]
  b = tmp[1][-1]
  if EorD == '1': # Enc
    ori.append(a)
    aft.append(b)
  elif EorD == '2':
    ori.append(b)
    aft.append(a)
  else:
    print('ERROR!')
    sys.exit()
ori += [chr(ord(i)+32) for i in ori]    
aft += [chr(ord(i)+32) for i in aft]    

'''
print(ori)
print(aft)
'''

tmp = ''
for c in inp:
  if c in ori:
    point = ori.index(c)
    tmp += aft[point]
  else:
    tmp += c
  
with open(outfile, 'w') as f:
  f.write(tmp)
  
  
print('Done!')
