# include <stdio.h>
# include <stdint.h>
# include <string.h>


char* replace(char str[], char chr, char rep) {
    global char tmp[strlen(str)+1];
    for (int32_t i  = 0;i<strlen(str);i++) {
        if (str[i] == chr) {
            tmp[i] = rep;
        } else {
            tmp[i] = str[i];
        }
    }   
    printf("%d\t", strlen(str));
    printf("\"%s\"\n", str);
    printf("%d\t", strlen(tmp));
    printf("\"%s\"\n", tmp);

    return tmp;
}


int main() {
    char str[] = "hello qqqq kokoko feiowfwio";
    char* res;
    char chr = ' ';
    char rep = 'X';
    res = replace(str, chr, rep);
    printf("%d\t", strlen(res));
    printf("\"%s\"\n", res);
    
}

