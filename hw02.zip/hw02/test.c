# include <stdio.h>
# include <stdint.h>
# include <stdlib.h>
# include <string.h>
# include <ctype.h>


struct _pair{
    char a;
    char b;
};

typedef struct _pair pair;

void mother(char* str) {
    printf("%s", str);
}

/*
void chkfile(FILE* fp) {
    if (!fp) {
        printf("open file error!\n");
        exit(0);
    }
}


char switch_case(char c) {
    char blank = ' ';
    return c^blank;
}


char sw(char c, char *alist, char mode) {
    if (mode == 0) {             //upper
        for (int32_t i = 0;i<26;++i) {
            //printf("%s\t%s\t%s\n", alist[i].a, c, alist[i].b);
            //printf("%d  ", i);
            if (alist[i][0] == c) {
                return alist[i][1];
            }
        }
    } else if (mode == 1) {     //lower
        c = switch_case(c);
        for (int32_t i = 0;i<26;++i) {
            if (switch_case(alist[i][0]) == c) {
                return switch_case(alist[i][1]);
            }
        }
    } else {
        printf("sw() error\n");
        exit(0);
    }
    //printf("\n");
}
*/
void x(pair *ali) {
    for (int i = 0;i<26;i++) {
        printf("%c : %c\n", ali[i].a, ali[i].b);
    }
}


int main(){
    //pair ali[26] = {{'a', 'b'}, {'v', 'r'}};
    char mo[9999] = "777777777777777777777777777";
    mother(mo);
    
    /*
    char alist[26][2];
    char buff[65536];
    char a, b;

    
    FILE *fin, *key, *fout;
    key = fopen("key.txt", "r");
    fin = fopen("a.txt", "r");
    fout = fopen("b.txt", "w");
    
    
    chkfile(key);
    chkfile(fin);
    chkfile(fout);
    
    
    for (int32_t i = 0;fscanf(key, "%c : %c\n", &alist[i][0], &alist[i][1]) != EOF;++i)
    */
    /*
    for (int32_t i = 0;i<26;++i) {
        printf("\"%c\":\"%c\"\n", alist[i].a, alist[i].b);
    }*/
    
    /*
    while (!feof(fin)) {
        fgets(buff, 65536, fin);
        printf("%s\n", buff);
        for (int32_t i = 0;i<65536;i++) {
            if (isupper(buff[i])) {
                buff[i] = sw(buff[i], alist, 0);
            } else if (islower(buff[i])) {
                buff[i] = sw(buff[i], alist, 1);
            }
        }
        printf("%s\n", buff);
        fputs(buff, fout);
        
    }

    fclose(key);
    fclose(fin);
    fclose(fout);
    */
}