# include <stdio.h>
# include <stdint.h>
# include <stdlib.h>
# include <string.h>
# include <ctype.h>



struct _pair{
    char a;
    char b;
};

typedef struct _pair pair;


char chkfile(FILE* fp, char* fname) {
    if (!fp) {
        printf("open %s error!\n", fname);
        exit(0);
    }
}


char switch_case(char c) {
    char blank = ' ';
    return c^blank;
}


char sw(char c, pair *alist, char mode, char eod) {
    if (eod == 1) {
        if (mode == 0) {             //upper
            //printf("mode%d\t", mode);
            for (int32_t i = 0;i<26;++i) {
                //printf("%d  ", i);
                //printf("[%c, %c, %c]\n", alist[i].a, c, alist[i].b);
                if (alist[i].a == c) {
                    return alist[i].b;
                }
            }
        } else if (mode == 1) {     //lower
            //printf("mode%d\t", mode);
            for (int32_t i = 0;i<26;++i) {
                if (switch_case(alist[i].a) == c) {
                    return switch_case(alist[i].b);
                }
            }
        } else {
            printf("sw() error\n");
            exit(0);
        }
        printf("\n");
    } else if (eod == 2) {
        if (mode == 0) {             //upper
            //printf("mode%d\t", mode);
            for (int32_t i = 0;i<26;++i) {
                //printf("%d  ", i);
                //printf("[%c, %c, %c]\n", alist[i].a, c, alist[i].b);
                if (alist[i].b == c) {
                    return alist[i].a;
                }
            }
        } else if (mode == 1) {     //lower
            //printf("mode%d\t", mode);
            for (int32_t i = 0;i<26;++i) {
                if (switch_case(alist[i].b) == c) {
                    return switch_case(alist[i].a);
                }
            }
        } else {
            printf("sw() error\n");
            exit(0);
        }
        printf("\n");        
    }
}


char chkeod(char m) {
    if (!(m < 3 && m>0)) {
        printf("error input of mode!\n");
        exit(0);
    }
}


int main(){
    pair alist[26];
    char buff[65536];
    char inp[256], out[256], keyli[256];
    int eod;

    
    FILE *fin, *key, *fout;
    
    printf("Please enter the input file: ");
    scanf("%s", inp);
    printf("Please enter the output file: ");
    scanf("%s", out);
    printf("Please enter the key file: ");
    scanf("%s", keyli);
    printf("Encryption (1) or Decryption (2): ");
    scanf("%d", &eod);
    chkeod(eod);
        
    
    key = fopen(keyli, "r");
    fin = fopen(inp, "r");
    fout = fopen(out, "w");
        
    
    chkfile(key, keyli);
    chkfile(fin, inp);
    chkfile(fout, out);
    
    for (int32_t i = 0;fscanf(key, "%c : %c\n", &alist[i].a, &alist[i].b) != EOF;++i) {}
    
    /*
    for (int32_t i = 0;i<26;++i) {
        printf("%d\t[%c, %c]\n", i, alist[i].a, alist[i].b);
    }
    */
    
    while (!feof(fin)) {
        fgets(buff, 65536, fin);
        printf("%s\n", buff);
        for (int32_t i = 0;buff[i] != '\0';i++) {
            //printf("%d\t%c\t", i, buff[i]);
            if (isupper(buff[i])) {
                //printf("lower%c\t",buff[i]);
                buff[i] = sw(buff[i], alist, 0, eod);
            } else if (islower(buff[i])) {
                //printf("upper%c\t",buff[i]);
                buff[i] = sw(buff[i], alist, 1, eod);
            }
        }
        printf("%s\n", buff);
        fputs(buff, fout);
        
    }

    fclose(key);
    fclose(fin);
    fclose(fout);
}