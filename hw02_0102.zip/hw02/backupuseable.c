# include <stdio.h>
# include <stdint.h>
# include <string.h>
# include <ctype.h>


void showcolor(char* keyword, int color) {
	/*
	30	Grey
	31	Red
	32	Green
	33	Yellow
	34	Blue
	35	Purple
	36	miku
	*/
	printf ("\033[1;%dm", color);
	printf ("%s", keyword);
	printf ("\033[m");
}


struct _locations {
	char *pos;
	char key[10];
};

typedef struct _locations locations;


void swap(locations *a, locations *b) {
    locations temp;
    temp = *a;
    *a = *b;
    *b = temp;
}


void bublesort(locations *locs, int32_t length) {
	for (int32_t i = 0;i<length-1;i++) {
		for (int32_t j = 0;j<length-1-i;j++) {
			if (locs[j].pos > locs[j+1].pos) {
				swap(&locs[j], &locs[j+1]);
			}
		}
	}
}


int8_t chk(char a) {
	// ok return 0;
	// ok : " ", (, ), {, }, [, ], "\n", ";", ":", "\t"
	// not ok return 1;
	// not ok : alpha, _
	char white_list[] = {'-', '.', ',', '/', '*', '&', ' ', '(', ')', '{', '}', '[', ']', '\n', ':', ';', '\t'};
	for (int32_t i = 0;i<sizeof(white_list)/sizeof(white_list[0]);i++) {
		if (a == white_list[i]) {
			return 0;
		}
	}
	return 1;
}


int8_t chka(char a) {
	// ok return 0;
	// ok : " ", (, ), {, }, [, ], "\n", ";", ":", "\t"
	// not ok return 1;
	// not ok : alpha, _
	if (isalpha(a)) { return 1; }
	if (a == '_') { return 1; }
	if (a == '$') { return 1; }
	/*
	char black_list[] = {'_', '$'};
	for (int32_t i = 0;i<sizeof(black_list)/sizeof(black_list[0]);i++) {
		if (a == black_list[i]) {
			return 1;
		}
	}
	*/
	return 0;
}



int main() {
	FILE *fp;
	char fname[256];
	int32_t size = 65536;
	char buff[size];
	int32_t space = 50;
	int8_t first = 0;
	locations locs[65536];
	locations tmp;
	char *now;
	char keywords[38][10] = { "break", "case", "char", "const",
							  "continue", "default", "do", "double", 
							  "else", "enum", "extern", "float", 
							  "for", "goto", "if", "include", 
							  "int8_t", "int16_t", "int32_t", "int", 
							  "int64_t", "long", "return", "short", 
							  "signed", "sizeof", "static", "struct", 
							  "switch", "typedef", "uint8_t", "uint16_t", 
							  "uint32_t", "uint64_t", "union", "unsigned", 
							  "void", "while" };

	printf("filename : ");
	scanf("%s", fname);
	//puts("0");
	fp = fopen(fname, "r");
	if (fp == NULL) {
		printf("Open File Error!\n");
		return 0;
	}
	//puts("0");
	int32_t count = 0;
	while (!feof(fp)) {
		//puts ("|||||||||||||||||||||||||");
		count++;
		//printf("%d\n", count);
		/*
		if (first == 0) {
			//puts("1");
			fgets(buff, size, fp);
			first = 1;
		} else {
			//puts("2");
			strcpy(buff, buff+strlen(buff)-space);
			fgets(buff+space, size-space, fp);
		}
		printf("%s", buff);
		*/

		//printf("%s\n", buff);
		
		fgets(buff, size, fp);
		printf ("%s", buff);
		//puts ("=================");
		int32_t idx = 0;
		char *ps[256] = {};
		int8_t flag = 0;
		for (int32_t i = 0;i<38;i++) {
			now = buff;
			while (now != 0) {
				now = strstr(now, keywords[i]);
				if (now == 0) { break; }
				if (chk((now-1)[0]) && chk((now+strlen(keywords[i]))[0])) { break; }
				if (chka((now-1)[0]) || chka((now+strlen(keywords[i]))[0])) { break; }
				for (int32_t i = 0;i<sizeof(ps)/sizeof(ps[0]);i++) {
					if (ps[i] == now) { flag = 1;break; }
				}
				if (flag) { break; }
				strcpy(locs[idx].key, keywords[i]);
				locs[idx].pos = now;
				now += strlen(keywords[i]);
				//printf("<<<%p\t%s\n", locs[idx].pos, locs[idx].key);
				ps[idx] = locs[idx].pos;
				idx++;

 			}

		}
		/*
		for (int32_t i = 0;i<idx;i++) {
			printf(">>> %p\t%s\n", locs[i].pos, locs[i].key);
		}
		*/
		bublesort(locs, idx);
		now = buff;
		if (!idx) {printf("%s", buff);}
		for (int32_t i = 0;i<idx;i++) {
			strcpy(locs[i].pos, "\0");
			printf("%s", now);
			showcolor(locs[i].key, 36);
			now = locs[i].pos+strlen(locs[i].key);
			if (i+1 == idx) {
				printf("%s\n", now);
			}
		}
		//puts ("$$$$$$$$$$$$$$$$$$$");


		/*
		for (int32_t i = 0;i<idx;i++) {
			printf(">>> %p\t%s\n", locs[i].pos, locs[i].key);
		}
		*/

	}
	//puts("0");
	
	//showcolor("c0xffee", 36);

}