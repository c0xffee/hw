# include <stdio.h>
# include <stdint.h>
# include <stdlib.h>
# include <string.h>
# include <ctype.h>



struct _pair{
    char a;
    char b;
};

typedef struct _pair pair;


void chkfile(FILE* fp) {
    if (!fp) {
        printf("open file error!\n");
        exit(0);
    }
}

/*
char switch_case(char c) {
    char blank = ' ';
    return c^blank;
}


char sw(char c, char *alist, char mode) {
    if (mode == 0) {             //upper
        for (int32_t i = 0;i<26;++i) {
            //printf("%s\t%s\t%s\n", alist[i].a, c, alist[i].b);
            //printf("%d  ", i);
            if (alist[i][0] == c) {
                return alist[i][1];
            }
        }
    } else if (mode == 1) {     //lower
        c = switch_case(c);
        for (int32_t i = 0;i<26;++i) {
            if (switch_case(alist[i][0]) == c) {
                return switch_case(alist[i][1]);
            }
        }
    } else {
        printf("sw() error\n");
        exit(0);
    }
    //printf("\n");
}
*/

int main(){
    pair alist[26];
    char buff[65536];
    char a, b;

    
    FILE *fin, *key, *fout;
    key = fopen("key.txt", "r");
    fin = fopen("a.txt", "r");
    fout = fopen("b.txt", "w");
    
    
    chkfile(key);
    chkfile(fin);
    chkfile(fout);
    
    
    for (int32_t i = 0;fscanf(key, "%c : %c\n", &alist[i].a, &alist[i].b) != EOF;++i)
    
    /*
    for (int32_t i = 0;i<26;++i) {
        printf("\"%c\":\"%c\"\n", alist[i].a, alist[i].b);
    }*/
    
    
    while (!feof(fin)) {
        fgets(buff, 65536, fin);
        printf("%s\n", buff);
        for (int32_t i = 0;i<65536;i++) {
            printf("outer%s\n", buff[i]);
            if (isupper(buff[i])) {
                printf("upper%c\n", buff[0]);
                for (int32_t i = 0;i<26;++i) {
                    printf("%s\t", alist[i].a);
                    printf("%s\t", buff[0]);
                    printf("%s\t", alist[i].b);
                    //printf("%d  ", i);
                    if (alist[i].a == buff[0]) {
                        buff[0] = alist[i].b;
                    }
                }
            } else if (islower(buff[0])) {
                printf("lower%c\n", buff[0]);
                for (int32_t i = 0;i<26;++i) {
                    if (alist[i].a == buff[0]^' ') {
                        buff[0] = alist[i].b^' ';
                    }
                }
            }
                
            printf("%s\n", buff);
            fputs(buff, fout);
        }    
    }

    fclose(key);
    fclose(fin);
    fclose(fout);
}