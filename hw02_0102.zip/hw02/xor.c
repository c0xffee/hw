# include <stdio.h>


int main() {
    char c = 'A';
    char blank = ' ';
    printf("%c", c^blank);
}