# include <stdio.h>
# include <stdint.h>
# include <string.h>


typedef struct hi{
    int id;
    int xd;
} hii;


void showcolor(char* keyword, int color) {
    /*
    30  Grey
    31  Red
    32  Green
    33  Yellow
    34  Blue
    35  Purple
    36  miku
    */
    printf ("\033[1;%dm", color);
    printf ("%s", keyword);
    printf ("\033[m\n");
}

void swap(hii *a, hii *b) {
    hii temp;
    temp = *a;
    *b = *a;
    *a = temp;
}

void bublesort(int *locs, int32_t length) {
    for (int32_t i = 0;i<length-1;i++) {
        for (int32_t j = 0;j<length-1-i;j++) {
            if (locs[j] > locs[j+1]) {
                swap(&locs[j], &locs[j+1]);
            }
        }
    }
}






int main() {
    hii hello[2] = {{10, 20}, {200, 199}};
    for (int i = 0;i<2;i++) {
        printf("[%d, %d]\t", hello[i].id, hello[i].xd);
    }
    puts("");
    swap(hello[0], hello[2]);
    for (int i = 0;i<2;i++) {
        printf("[%d, %d]\t", hello[i].id, hello[i].xd);
    }
    puts("");
    /*
    char *po = NULL;
    po = strstr("is hello?", "hello");
    if (po!=0) {
        printf("%p\n", po);
    }
    if (po < po+10) {printf("%p < %p\n", po, po+10);}
    showcolor("c0xffee", 36);
    */
    /*
    int arr[] = {9,5,1,2,6,47,5,78,65,98,6,32,1,45,8,900};
    int length = sizeof(arr)/sizeof(arr[0]);
    printf("%d\n", length);
    bublesort(arr, length);
    for (int i = 0;i<length;i++) {
        printf("%d\t", arr[i]);
    }
    puts("");
    */
}